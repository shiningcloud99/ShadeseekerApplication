package com.example.myapplication;

public class BrandProductItem {
    static int [] productsimage = {
            R.drawable.n00_glow, R.drawable.n00_matte, R.drawable.n01_glow, R.drawable.n03_silk,
            R.drawable.w01_glow,R.drawable.w01_silk, R.drawable.w02_matte,
            R.drawable.c01_glow
    };

    static String[] brandname = {
            "luxcrime", "luxcrime", "luxcrime", "luxcrime", "luxcrime", "luxcrime", "luxcrime", "luxcrime"

    };

    static String[] productname = {
            "Perfecting Cover Cushion Glow", "Perfecting Cover Cushion Matte", "Perfecting Cover Cushion Glow",
            "Radiant Silk Foundation", "Perfecting Cover Cushion Glow", "Radiant Silk Foundation", "Perfecting Cover Cushion Matte",
            "Perfecting Cover Cushion Glow"

    };

    static String[] shade = {
            "N01", "N00", "N01", "N03", "W01","W01", "W02", "C01"
    };
}
