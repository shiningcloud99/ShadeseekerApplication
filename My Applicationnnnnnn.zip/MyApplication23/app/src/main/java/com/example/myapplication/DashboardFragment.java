package com.example.myapplication;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class DashboardFragment extends Fragment {
    private EditText brandName, brandDescription;
    private Button uploadBrandButton, selectImageButton;
    private ImageView brandImageView;
    private ProgressBar progressBar;
    private DatabaseReference brandsRef;
    private StorageReference storageRef;
    private Uri imageUri;

    private ActivityResultLauncher<Intent> activityResultLauncher;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.admin_fragment_create, container, false);

        brandName = root.findViewById(R.id.brandName);
        brandDescription = root.findViewById(R.id.brandDescription);
        uploadBrandButton = root.findViewById(R.id.uploadBrandButton);
        selectImageButton = root.findViewById(R.id.selectImageButton);
        brandImageView = root.findViewById(R.id.brandImageView);
        progressBar = root.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);

        brandsRef = FirebaseDatabase.getInstance().getReference("brands");
        storageRef = FirebaseStorage.getInstance().getReference("images");

        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        uploadBrandButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageUri != null) {
                    uploadImage();
                } else {
                    uploadBrand(null);
                }
            }
        });

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        imageUri = result.getData().getData();
                        Picasso.get().load(imageUri).into(brandImageView);
                    }
                });

        return root;
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        activityResultLauncher.launch(intent);
    }

    private void uploadImage() {
        if (imageUri != null) {
            progressBar.setVisibility(View.VISIBLE);
            final StorageReference fileReference = storageRef.child(System.currentTimeMillis() + "." + getFileExtension(imageUri));
            fileReference.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    uploadBrand(uri.toString());
                                    progressBar.setVisibility(View.INVISIBLE);
                                }
                            });
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressBar.setVisibility(View.INVISIBLE);
                            Toast.makeText(getActivity(), "Failed to upload image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadBrand(String imageUrl) {
        String name = brandName.getText().toString().trim();
        String description = brandDescription.getText().toString().trim();

        if (!name.isEmpty()) {
            String id = brandsRef.push().getKey();
            Brand brand = new Brand(id, name, description, imageUrl);
            if (id != null) {
                brandsRef.child(id).setValue(brand)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(getActivity(), "Brand uploaded!", Toast.LENGTH_SHORT).show();
                            brandName.setText("");
                            brandDescription.setText("");
                            brandImageView.setImageResource(android.R.color.transparent);
                            imageUri = null;
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(getActivity(), "Failed to upload brand: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
            }
        } else {
            Toast.makeText(getActivity(), "Please fill the brand name", Toast.LENGTH_SHORT).show();
        }
    }
}
